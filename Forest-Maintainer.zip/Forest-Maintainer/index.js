const { Client, GatewayIntentBits, Collection } = require('discord.js');
const config = require('./config');
const commandHandler = require('./handlers/commandHandler');
const logger = require('./utils/logger');
const levelingSystem = require('./utils/levelingSystem');
const automod = require('./utils/automod');
const countingGame = require("./utils/countingGame");
const secretWordFinder = require("./utils/secretWordFinder");
const { handleMessage, handleDelete } = require("./utils/automod");
// 1. Create the client first
const client = new Client({
    intents: [
        GatewayIntentBits.Guilds,
        GatewayIntentBits.GuildMessages,
        GatewayIntentBits.GuildMembers,
        GatewayIntentBits.MessageContent,
        GatewayIntentBits.GuildModeration
    ]
});

// 2. Initialize commands collection
client.commands = new Collection();

// 3. Load commands
commandHandler.loadCommands(client);

// 4. Bot ready event
client.once('ready', () => {
    console.log(`${client.user.tag} is online and ready!`);
    logger.log('Bot started successfully', 'INFO');
    
    // Register slash commands
    commandHandler.registerSlashCommands(client);
});

// 5. Handle slash command interactions
client.on('interactionCreate', async (interaction) => {
    if (!interaction.isChatInputCommand()) return;

    const command = client.commands.get(interaction.commandName);
    if (!command) return;

    try {
        await command.execute(interaction);
        logger.log(`Command ${interaction.commandName} executed by ${interaction.user.tag}`, 'INFO');
    } catch (error) {
        console.error('Error executing command:', error);
        logger.log(`Error executing command ${interaction.commandName}: ${error.message}`, 'ERROR');
        
        const errorMessage = 'There was an error while executing this command!';
        if (interaction.replied || interaction.deferred) {
            await interaction.followUp({ content: errorMessage, ephemeral: true });
        } else {
            await interaction.reply({ content: errorMessage, ephemeral: true });
        }
    }
});

// 6. Handle message events
client.on('messageCreate', async (message) => {
    if (message.author.bot) return;
    if (!message.guild) return;

    try {
        await levelingSystem.handleMessage(message);
    } catch (error) {
        console.error('Error in leveling system:', error);
        logger.log(`Leveling system error: ${error.message}`, 'ERROR');
    }

    // Run automod
    automod.handleMessage(message);

    // Run counting game
    countingGame.handleMessage(message);

    // Run secret word finder
    secretWordFinder.handleMessage(message);
});
// When a new message is sent
client.on("messageCreate", handleMessage);

// When a message is deleted
client.on("messageDelete", handleDelete);

// 7. Handle errors
client.on('error', (error) => {
    console.error('Discord client error:', error);
    logger.log(`Discord client error: ${error.message}`, 'ERROR');
});

process.on('unhandledRejection', (error) => {
    console.error('Unhandled promise rejection:', error);
    logger.log(`Unhandled rejection: ${error.message}`, 'ERROR');
});

// 8. Login to Discord
client.login(config.BOT_TOKEN);

