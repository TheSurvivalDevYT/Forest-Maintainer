const { EmbedBuilder } = require("discord.js");
const secretWordCmd = require("../commands/secretword");

// CONFIG: where to send ping and who to ping
const TARGET_CHANNEL_ID = "1407808005629673585";
const TARGET_USER_ID = "1179217779103105075";
module.exports = {
    handleMessage: async (message) => {
        if (message.author.bot) return;

        const word = secretWordCmd.getSecretWord();
        const maxUses = secretWordCmd.getMaxUses();
        const usedCount = secretWordCmd.getUsedCount();

        if (!word) return;
        if (usedCount >= maxUses) return;

        const regex = new RegExp(`\\b${word}\\b`, "i");
        if (!regex.test(message.content.toLowerCase())) return;

        // Increment use
        secretWordCmd.incrementUse();

        try {
            const targetChannel = await message.guild.channels.fetch(TARGET_CHANNEL_ID).catch(() => null);
            if (!targetChannel) return;

            const embed = new EmbedBuilder()
                .setTitle("🎉 Secret Word Found!")
                .setDescription(`${message.author} found the secret word **${word}**!`)
                .setColor("Green")
                .addFields({ name: "Uses Left", value: `${maxUses - secretWordCmd.getUsedCount()}` })
                .setTimestamp();

            await targetChannel.send({
                content: `<@${TARGET_USER_ID}>`,
                embeds: [embed],
            });
        } catch (err) {
            console.error("[SecretWordFinder] Error:", err);
        }
    }
};
