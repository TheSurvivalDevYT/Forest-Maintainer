const fs = require("fs");
const path = require("path");

const COUNTING_CHANNEL_ID = "1416609542136926268"; // Your counting channel

const dataFile = path.join(__dirname, "../data/counting.json");
let saving = false;

// Load state safely
function loadData() {
    if (!fs.existsSync(dataFile)) {
        console.log("[CountingGame] No save file, starting fresh.");
        return { lastNumber: 0, lastUserId: null };
    }
    try {
        const raw = fs.readFileSync(dataFile, "utf8");
        return JSON.parse(raw);
    } catch (err) {
        console.error("[CountingGame] Failed to read save file, resetting state:", err);
        return { lastNumber: 0, lastUserId: null };
    }
}

// Save state safely with atomic write
function saveData(data) {
    if (saving) return;
    saving = true;
    const tmpFile = dataFile + ".tmp";

    try {
        fs.writeFileSync(tmpFile, JSON.stringify(data, null, 2));
        fs.renameSync(tmpFile, dataFile); // atomic replace
        console.log("[CountingGame] Saved:", data);
    } catch (err) {
        console.error("[CountingGame] Failed to save:", err);
    } finally {
        saving = false;
    }
}

// Load initial state
let state = loadData();

module.exports = {
    handleMessage: async (message) => {
        if (message.author.bot) return;
        if (message.channel.id !== COUNTING_CHANNEL_ID) return;

        const content = message.content.trim();

        // Only allow exact digits
        if (!/^\d+$/.test(content)) {
            try { await message.delete(); } catch {}
            return;
        }

        const number = Number(content);

        // Rule 1: Must be next number
        if (number !== state.lastNumber + 1) {
            try { await message.delete(); } catch {}
            return;
        }

        // Rule 2: Same user cannot go twice
        if (message.author.id === state.lastUserId) {
            try { await message.delete(); } catch {}
            return;
        }

        // Passed checks → update state + save
        state.lastNumber = number;
        state.lastUserId = message.author.id;
        saveData(state);

        console.log("[CountingGame] Accepted:", number, "by", message.author.tag);
    }
};
