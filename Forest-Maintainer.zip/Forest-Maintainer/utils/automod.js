const fs = require("fs");
const path = require("path");
const { EmbedBuilder } = require("discord.js");

const LOG_CHANNEL_ID = "1413623155318198353";
const MOD_ROLE_ID = "1407825640362872923";

// Load badwords.txt into an array
const badwordsPath = path.join(__dirname, "../data/badwords.txt");
const bannedWords = fs.readFileSync(badwordsPath, "utf-8")
  .split("\n")
  .map(w => w.trim().toLowerCase())
  .filter(Boolean);

async function logMessage(message, reason, pingMods = false) {
    try {
        // Fetch log channel
        const logChannel = await message.guild.channels.fetch(LOG_CHANNEL_ID).catch(() => null);
        if (!logChannel) return;

        // Collect attachments
        const attachments = message.attachments.map(att => att.url);
        const attachmentText = attachments.length > 0
            ? attachments.join("\n")
            : "None";

        // Build embed
        const embed = new EmbedBuilder()
            .setTitle(reason)
            .setColor(pingMods ? "Red" : "Orange")
            .addFields(
                { name: "User", value: `${message.author?.tag || "Unknown"} (${message.author?.id || "N/A"})` },
                { name: "Message", value: message.content || "*No content*" },
                { name: "Channel", value: `<#${message.channel?.id || "Unknown"}>` },
                { name: "Attachments", value: attachmentText }
            )
            .setTimestamp();

        // Show image preview if available
        if (attachments.length > 0 && /\.(png|jpe?g|gif|webp)$/i.test(attachments[0])) {
            embed.setImage(attachments[0]);
        }

        // Send log
        await logChannel.send({
            content: pingMods ? `<@&${MOD_ROLE_ID}>` : null,
            embeds: [embed],
        });

    } catch (err) {
        console.error("Log error:", err);
    }
}

module.exports = {
    handleMessage: async (message) => {
        if (message.author.bot) return;

        const lowerMsg = message.content.toLowerCase();

        // Check for banned words
        const containsBannedWord = bannedWords.some(word =>
            new RegExp(`\\b${word}\\b`, "i").test(lowerMsg)
        );

        if (!containsBannedWord) return;

        // Delete flagged message
        if (message.guild.members.me.permissions.has("ManageMessages")) {
            await message.delete();
        }

        // Log with mod ping
        await logMessage(message, "🚨 AutoMod Alert (Flagged & Deleted)", true);
    },

    handleDelete: async (message) => {
        // Ignore bot deletions
        if (message.author?.bot) return;

        // Log deleted message
        await logMessage(message, "🗑️ Message Deleted", false);
    }
};
