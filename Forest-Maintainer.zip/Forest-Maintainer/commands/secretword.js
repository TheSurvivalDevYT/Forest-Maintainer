const { SlashCommandBuilder, PermissionFlagsBits } = require("discord.js");
const fs = require("fs");
const path = require("path");

const dataFile = path.join(__dirname, "../data/secretword.json");

// Helper to load/save state
function loadData() {
    if (!fs.existsSync(dataFile)) return { secretWord: null, maxUses: 0, usedCount: 0 };
    return JSON.parse(fs.readFileSync(dataFile, "utf8"));
}

function saveData(state) {
    fs.writeFileSync(dataFile, JSON.stringify(state, null, 2));
}

let state = loadData();

module.exports = {
    data: new SlashCommandBuilder()
        .setName("secretword")
        .setDescription("Set or check the secret word")
        .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
        .addSubcommand(sub =>
            sub.setName("set")
                .setDescription("Set a new secret word")
                .addStringOption(opt =>
                    opt.setName("word")
                        .setDescription("The secret word to look for")
                        .setRequired(true)
                )
                .addIntegerOption(opt =>
                    opt.setName("uses")
                        .setDescription("How many times it can be found")
                        .setRequired(true)
                )
        )
        .addSubcommand(sub =>
            sub.setName("status")
                .setDescription("Check current secret word status")
        ),

    async execute(interaction) {
        const sub = interaction.options.getSubcommand();

        if (sub === "set") {
            const word = interaction.options.getString("word").toLowerCase();
            const uses = interaction.options.getInteger("uses");

            state = { secretWord: word, maxUses: uses, usedCount: 0 };
            saveData(state);

            await interaction.reply({
                content: `✅ Secret word set to **${word}** with **${uses}** uses.`,
                ephemeral: true
            });
        }

        if (sub === "status") {
            if (!state.secretWord) {
                await interaction.reply({ content: "❌ No secret word set.", ephemeral: true });
            } else {
                await interaction.reply({
                    content: `📖 Secret word is **${state.secretWord}**. Uses: ${state.usedCount}/${state.maxUses}`,
                    ephemeral: true
                });
            }
        }
    },

    // Expose state functions for other modules
    getSecretWord: () => state.secretWord,
    getMaxUses: () => state.maxUses,
    getUsedCount: () => state.usedCount,
    incrementUse: () => {
        state.usedCount++;
        saveData(state);
    }
};
